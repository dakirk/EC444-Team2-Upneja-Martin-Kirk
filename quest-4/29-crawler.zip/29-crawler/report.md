#  Crawler

Author: David Kirk, 2019-11-06

## Summary
For this skill, we learned to control the drive motors and steering servo on the crawler using PWM signals and an H-bridge.

## Modules, Tools, Source Used in Solution
Standard idf.py toolchain, MCPWM example code

## Supporting Artifacts
[![Crawler demo](http://img.youtube.com/vi/YvUEnZIdfUU/0.jpg)](http://www.youtube.com/watch?v=YvUEnZIdfUU "Crawler demo")

-----

## Reminders
- Repo is private
